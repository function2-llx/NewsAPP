package com.example.newsapp.events;

abstract class EventBase {
}
