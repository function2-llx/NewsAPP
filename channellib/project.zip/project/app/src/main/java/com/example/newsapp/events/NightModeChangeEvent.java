package com.example.newsapp.events;

public class NightModeChangeEvent extends EventBase {

}
