package com.jaydenxiao.common.base;

/**
 * des:baseModel
 * Created by xsf
 * on 2016.08.14:50
 */
public interface BaseModel {
}
