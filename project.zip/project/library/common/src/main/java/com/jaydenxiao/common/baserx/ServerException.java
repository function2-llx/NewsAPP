package com.jaydenxiao.common.baserx;

/**
 * des:服务器请求异常
 * Created by xsf
 * on 2016.09.10:16
 */
public class ServerException extends Exception{

    public ServerException(String msg){
        super(msg);
    }

}
