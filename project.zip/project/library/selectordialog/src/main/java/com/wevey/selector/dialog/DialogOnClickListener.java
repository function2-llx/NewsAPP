package com.wevey.selector.dialog;

import android.view.View;

/**
 * Created by weavey
 * on 2016-09-05.
 * todo
 */
public interface DialogOnClickListener {

    void clickLeftButton(View view);

    void clickRightButton(View view);
}
