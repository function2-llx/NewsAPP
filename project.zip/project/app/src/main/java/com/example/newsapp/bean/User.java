package com.example.newsapp.bean;

/**
 * des:
 * Created by xsf
 * on 2016.09.9:54
 */
public class User {
}
