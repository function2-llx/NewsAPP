package com.trs.channellib.channel.channel.helper;

/**
 * Item移动后 触发
 * Created by YoKeyword on 15/12/28.
 */
public interface OnItemMoveListener {
    void onItemMove(int fromPosition, int toPosition);
}
